<?php
//start de sessie
session_start();

//vernietig de sessie
session_destroy();

//ga naar de inlogpagina
header("location:../../index.php")
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
	<title>Logout</title>
</head>

<body>
	
</body>
</html>